Dataset name : Handglove Detection.v8i.yolov8
Dataset source : Roboflow Universe (https://universe.roboflow.com/knowledgeflex/handglove-detection-7ftlj)
Model used : YOLOv8n - the nano version of YOLOv8.
run this script by google colab.